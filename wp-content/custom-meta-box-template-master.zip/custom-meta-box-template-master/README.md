Custom Meta Box Template
========================

Plugin template for creating custom meta boxes in the WordPress admin area.

This plugin was created for the [WordPress Meta Boxes: a Comprehensive Developer’s Guide](http://themefoundation.com/wordpress-meta-boxes-guide/) tutorial.
